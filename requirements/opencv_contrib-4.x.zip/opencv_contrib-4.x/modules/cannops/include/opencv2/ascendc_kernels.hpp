#ifndef ASCENDC_KERNELS_H
#define ASCENDC_KERNELS_H

#include "../../ascendc_kernels/kernel_tiling_types.h"
#include "aclrtlaunch_threshold_opencv.h"

#endif //ASCENDC_KERNELS_H
